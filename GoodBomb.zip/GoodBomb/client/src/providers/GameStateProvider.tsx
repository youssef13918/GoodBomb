import React, { ReactNode, useState, useEffect, useCallback } from 'react';
import { GameState, WSMessage } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { GameStateContext } from '@/lib/useGameState';

interface GameStateProviderProps {
  children: ReactNode;
}

export const GameStateProvider: React.FC<GameStateProviderProps> = ({ children }) => {
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [isExploding, setIsExploding] = useState(false);
  const [showWinnerModal, setShowWinnerModal] = useState(false);
  const [winnerInfo, setWinnerInfo] = useState({
    winner: null as string | null,
    amount: 0
  });
  
  const { toast } = useToast();

  // Connect to WebSocket server
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const newSocket = new WebSocket(wsUrl);
    
    newSocket.onopen = () => {
      console.log('WebSocket connected');
      setIsConnected(true);
      
      toast({
        title: "Connected to Game Server",
        description: "You're now connected to the GoodBomb game",
      });
    };
    
    newSocket.onclose = () => {
      console.log('WebSocket disconnected');
      setIsConnected(false);
      
      toast({
        title: "Disconnected from Game Server",
        description: "Lost connection to the game server",
        variant: "destructive"
      });
    };
    
    newSocket.onerror = (error) => {
      console.error('WebSocket error:', error);
      setIsConnected(false);
      
      toast({
        title: "Connection Error",
        description: "Failed to connect to game server",
        variant: "destructive"
      });
    };
    
    newSocket.onmessage = (event) => {
      try {
        const message: WSMessage = JSON.parse(event.data);
        
        switch (message.type) {
          case 'gameState':
            setGameState(message.payload);
            break;
            
          case 'explosion':
            setIsExploding(true);
            setWinnerInfo({
              winner: message.payload.winner,
              amount: message.payload.amount
            });
            
            // Show winner modal after explosion animation
            setTimeout(() => {
              setIsExploding(false);
              setShowWinnerModal(true);
            }, 1000);
            break;
            
          case 'gameReset':
            setGameState(message.payload);
            setShowWinnerModal(false);
            break;
            
          case 'playerCount':
            if (gameState) {
              setGameState({
                ...gameState,
                playerCount: message.payload.count
              });
            }
            break;
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
    
    setSocket(newSocket);
    
    // Cleanup on unmount
    return () => {
      newSocket.close();
    };
  }, [toast]);
  
  // Function to press the button
  const pressButton = useCallback((walletAddress: string) => {
    if (!socket || socket.readyState !== WebSocket.OPEN) {
      toast({
        title: "Connection Error",
        description: "Not connected to game server",
        variant: "destructive"
      });
      return;
    }
    
    const message: WSMessage = {
      type: 'buttonPress',
      payload: { walletAddress }
    };
    
    socket.send(JSON.stringify(message));
  }, [socket, toast]);

  return (
    <GameStateContext.Provider value={{
      gameState, 
      isConnected, 
      isExploding, 
      showWinnerModal, 
      winnerInfo, 
      pressButton
    }}>
      {children}
    </GameStateContext.Provider>
  );
};