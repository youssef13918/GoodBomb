import { useState } from 'react';
import { motion } from 'framer-motion';
import { useGameState } from '@/lib/useGameState';
import { useWorldApp } from '@/lib/useWorldApp';
import { useToast } from '@/hooks/use-toast';

interface ActionButtonProps {
  disabled: boolean;
  walletAddress: string | null;
}

export default function ActionButton({ 
  disabled, 
  walletAddress 
}: ActionButtonProps) {
  const [isPressed, setIsPressed] = useState(false);
  const [isPaying, setIsPaying] = useState(false);
  const { pressButton } = useGameState();
  const { sendTransaction } = useWorldApp();
  const { toast } = useToast();

  const handleButtonPress = async () => {
    if (disabled || !walletAddress || isPaying) return;
    
    setIsPaying(true);
    setIsPressed(true);
    
    try {
      // Send transaction through World App
      const txResult = await sendTransaction(0.1);
      
      if (txResult) {
        // If transaction successful, update the game
        pressButton(walletAddress);
        
        toast({
          title: "Button Pressed!",
          description: "You pressed the button and paid 0.1 WLD",
        });
      } else {
        toast({
          title: "Payment Failed",
          description: "Could not complete the payment of 0.1 WLD",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Error pressing button:', error);
      toast({
        title: "Error",
        description: "Failed to press the button",
        variant: "destructive"
      });
    } finally {
      setIsPaying(false);
      setTimeout(() => setIsPressed(false), 150);
    }
  };

  return (
    <motion.button 
      className={`relative bg-[#FF0000] text-white font-orbitron font-bold text-2xl rounded-full
        w-48 h-48 border-4 border-gray-800 flex items-center justify-center focus:outline-none mb-6
        ${disabled ? 'opacity-50 cursor-not-allowed' : 'hover:bg-[#CC0000] cursor-pointer'}
        transition-transform duration-100`}
      style={{
        boxShadow: isPressed 
          ? '0 3px 0 rgb(150, 8, 8), 0 4px 6px rgba(0,0,0,0.4)'
          : '0 8px 0 rgb(150, 8, 8), 0 12px 10px rgba(0,0,0,0.6)',
        transform: isPressed ? 'translateY(5px)' : 'translateY(0)'
      }}
      whileTap={{ scale: 0.98 }}
      onClick={handleButtonPress}
      disabled={disabled || isPaying}
    >
      <div className="relative text-center">
        <div className="rounded-full bg-[#FFD700] w-24 h-24 mx-auto mb-1 flex items-center justify-center">
          <span className="text-2xl text-black">{isPaying ? "PAYING..." : "PRESS"}</span>
        </div>
        <div className="text-xs">PAY 0.1 WLD</div>
      </div>
      
      {/* Button highlight effect on hover */}
      <div 
        className={`absolute top-0 left-0 w-full h-full bg-radial-gradient rounded-full transition-opacity duration-200
          ${disabled ? 'opacity-0' : 'opacity-0 hover:opacity-20'}`}
        style={{
          background: 'radial-gradient(circle, rgba(255,255,255,0.2) 0%, rgba(255,255,255,0) 70%)'
        }}
      ></div>
    </motion.button>
  );
}
