export default function GameInstructions() {
  return (
    <div className="game-instructions max-w-md w-full px-4 py-2 mb-4">
      <div className="metal-container rounded-lg p-4 
        bg-gradient-to-br from-[#1a2e44] to-[#0D1B2A] border border-[#234863] 
        shadow-[inset_0_0_10px_rgba(0,0,0,0.6),_0_5px_15px_rgba(0,0,0,0.4)]">
        <h3 className="text-center text-[#FFD700] font-orbitron text-sm mb-3">CÓMO JUGAR</h3>
        
        <div className="grid gap-3">
          <div className="flex items-start gap-2">
            <div className="bg-[#FFD700] text-[#0D1B2A] rounded-full w-5 h-5 flex items-center justify-center shrink-0 font-bold text-xs">1</div>
            <div className="text-xs text-gray-300">
              Presiona el botón y paga <span className="text-[#FFD700] font-medium">0.1 WLD</span> para participar
            </div>
          </div>
          
          <div className="flex items-start gap-2">
            <div className="bg-[#FFD700] text-[#0D1B2A] rounded-full w-5 h-5 flex items-center justify-center shrink-0 font-bold text-xs">2</div>
            <div className="text-xs text-gray-300">
              <span className="text-[#FFD700] font-medium">El cronómetro se reinicia</span> a 4 minutos cuando alguien presiona el botón
            </div>
          </div>
          
          <div className="flex items-start gap-2">
            <div className="bg-[#FFD700] text-[#0D1B2A] rounded-full w-5 h-5 flex items-center justify-center shrink-0 font-bold text-xs">3</div>
            <div className="text-xs text-gray-300">
              El cronómetro cambia a <span className="text-orange-500 font-medium">naranja</span> cuando queda 1 minuto y a <span className="text-red-500 font-medium">rojo</span> cuando quedan 30 segundos
            </div>
          </div>
          
          <div className="flex items-start gap-2">
            <div className="bg-[#FFD700] text-[#0D1B2A] rounded-full w-5 h-5 flex items-center justify-center shrink-0 font-bold text-xs">4</div>
            <div className="text-xs text-gray-300">
              Si el cronómetro llega a <span className="text-red-500 font-medium">0:00</span>, ¡la bomba explota! El <span className="text-[#FFD700] font-medium">último jugador</span> que presionó el botón gana todo el bote
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
