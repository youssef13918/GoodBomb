import { motion } from 'framer-motion';

interface PotAmountProps {
  amount: number;
}

export default function PotAmount({ amount }: PotAmountProps) {
  return (
    <div className="w-full metal-container rounded-lg p-3 mb-8
      bg-gradient-to-br from-[#1a2e44] to-[#0D1B2A] border border-[#234863] 
      shadow-[inset_0_0_10px_rgba(0,0,0,0.6),_0_5px_15px_rgba(0,0,0,0.4)]">
      <div className="flex justify-between items-center">
        <div className="w-2.5 h-2.5 rounded-full bg-gradient-to-br from-[#95A5A6] to-[#7F8C8D] shadow-[inset_0_0_2px_rgba(0,0,0,0.6)]"></div>
        <div className="text-center">
          <h2 className="text-sm uppercase text-gray-400 font-rubik">Current Pot</h2>
          <motion.div 
            key={amount.toFixed(1)}
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.3 }}
            className="text-[#00C853] text-2xl font-orbitron font-bold"
          >
            {amount.toFixed(1)} WLD
          </motion.div>
        </div>
        <div className="w-2.5 h-2.5 rounded-full bg-gradient-to-br from-[#95A5A6] to-[#7F8C8D] shadow-[inset_0_0_2px_rgba(0,0,0,0.6)]"></div>
      </div>
    </div>
  );
}
