import { useState } from 'react';
import { useGameState } from '@/lib/useGameState';
import { motion, AnimatePresence } from 'framer-motion';

export default function RecentPlayersList() {
  const { gameState } = useGameState();
  const [expanded, setExpanded] = useState(true); // Start expanded

  // Si no hay jugadores recientes, no mostramos nada
  if (!gameState?.recentPlayers || gameState.recentPlayers.length === 0) {
    return null;
  }

  // Acortar las direcciones de wallet para mostrar
  const formatWalletAddress = (address: string) => {
    if (!address) return '';
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  const displayedPlayers = gameState.recentPlayers.slice(0, 5); // Show only the last 5 players

  return (
    <div className="mt-4 w-full">
      <div 
        className="flex items-center justify-between cursor-pointer mb-2 p-2 bg-[#1e293b] rounded-md"
        onClick={() => setExpanded(!expanded)}
      >
        <h3 className="text-xl font-semibold text-[#FFD700]">Últimos jugadores</h3>
        <span className="text-gray-300">
          {expanded ? '▲' : '▼'}
        </span>
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <ul className="bg-[#1e293b] rounded-md p-4 space-y-2 max-h-60 overflow-y-auto">
              {displayedPlayers.map((player, index) => (
                <motion.li 
                  key={`${player}-${index}`}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`flex justify-between items-center p-2 ${index === 0 ? 'bg-[#374151]' : ''} rounded-md`}
                >
                  <div className="flex items-center">
                    <span className="text-gray-300 mr-2">{index + 1}.</span>
                    <span className={index === 0 ? 'text-[#FFD700] font-medium' : 'text-white'}>
                      {formatWalletAddress(player)}
                    </span>
                  </div>
                  {index === 0 && (
                    <span className="text-xs bg-[#FFD700] text-[#0D1B2A] px-2 py-1 rounded-full">
                      Último
                    </span>
                  )}
                </motion.li>
              ))}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}