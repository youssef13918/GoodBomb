import { motion } from 'framer-motion';

interface LastPlayerInfoProps {
  player: string | null;
}

export default function LastPlayerInfo({ player }: LastPlayerInfoProps) {
  return (
    <div className="text-center mb-2">
      <h3 className="text-sm uppercase text-gray-400 font-rubik">Last Player</h3>
      <motion.div 
        key={player || 'waiting'}
        initial={{ opacity: 0, y: -5 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="text-white text-lg font-rubik"
      >
        {player || 'Waiting for players...'}
      </motion.div>
    </div>
  );
}
