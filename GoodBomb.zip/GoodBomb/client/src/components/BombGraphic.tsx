
import { useMemo } from 'react';
import { motion } from 'framer-motion';

interface BombGraphicProps {
  timeInSeconds: number;
  isShaking: boolean;
  isExploding: boolean;
}

export default function BombGraphic({ 
  timeInSeconds, 
  isShaking,
  isExploding 
}: BombGraphicProps) {
  const circumference = 2 * Math.PI * 52;
  const timerProgress = (timeInSeconds / 240) * 100;
  const dashOffset = circumference - (timerProgress / 100) * circumference;

  const timerColor = useMemo(() => {
    if (timeInSeconds <= 30) return '#FF0000';
    if (timeInSeconds <= 60) return '#FFA500';
    return '#FFD700';
  }, [timeInSeconds]);

  return (
    <div className="relative w-full flex justify-center">
      {isExploding && (
        <motion.div 
          className="absolute top-1/2 left-1/2 rounded-full z-50 pointer-events-none"
          style={{
            background: 'radial-gradient(circle, #FF6B00 0%, #D10808 40%, rgba(209, 8, 8, 0) 70%)',
          }}
          initial={{ width: 0, height: 0, x: '-50%', y: '-50%', opacity: 0 }}
          animate={{ 
            width: '300vw', 
            height: '300vw',
            x: '-50%', 
            y: '-50%',
            opacity: [0, 1, 0.8, 0],
          }}
          transition={{ duration: 1 }}
        />
      )}

      <motion.div 
        className="relative w-32 h-32 mb-6"
        animate={isShaking ? {
          x: [0, -2, 2, -2, 2, 0],
        } : {}}
        transition={isShaking ? {
          repeat: Infinity,
          duration: 0.5,
        } : {}}
      >
        <div className="relative flex justify-center items-center">
          <svg className="absolute w-[140px] h-[140px]" viewBox="0 0 140 140">
            <circle 
              cx="70" 
              cy="70" 
              r="52" 
              fill="none" 
              stroke="#333" 
              strokeWidth="4"
            />
            <circle 
              cx="70" 
              cy="70" 
              r="52" 
              fill="none" 
              stroke={timerColor} 
              strokeWidth="6"
              strokeLinecap="round"
              strokeDasharray={circumference} 
              strokeDashoffset={dashOffset}
              transform="rotate(-90 70 70)"
              style={{
                transition: 'stroke-dashoffset 1s, stroke 0.5s',
              }}
            />
          </svg>

          <motion.div 
            className="w-32 h-32 flex items-center justify-center relative z-10"
            animate={isShaking ? {} : { scale: [1, 1.02, 1] }}
            transition={isShaking ? {} : {
              repeat: Infinity,
              duration: 2,
            }}
          >
            <div className="w-24 h-24 bg-gray-800 rounded-full shadow-lg"/>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
