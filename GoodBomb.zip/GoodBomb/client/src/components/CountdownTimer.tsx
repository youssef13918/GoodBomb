
import { useMemo } from 'react';
import { motion } from 'framer-motion';

interface CountdownTimerProps {
  timeInSeconds: number;
  isWarning: boolean;
  potAmount: number;
}

export default function CountdownTimer({ timeInSeconds, isWarning, potAmount }: CountdownTimerProps) {
  const formattedTime = useMemo(() => {
    const mins = Math.floor(timeInSeconds / 60);
    const secs = timeInSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }, [timeInSeconds]);

  return (
    <div className="w-full metal-container rounded-lg p-5 mb-8 
      bg-gradient-to-br from-[#1a2e44] to-[#0D1B2A] border border-[#234863] 
      shadow-[inset_0_0_10px_rgba(0,0,0,0.6),_0_5px_15px_rgba(0,0,0,0.4)]">
      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col items-center">
          <h2 className="text-sm uppercase text-gray-400 font-rubik">Time Remaining</h2>
          <motion.div 
            key={formattedTime}
            initial={{ scale: 1.2, opacity: 0.8 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className={`text-4xl font-orbitron font-bold ${
              isWarning 
                ? 'text-[#FF8800] animate-pulse'
                : 'text-[#FFD700] animate-glow'
            }`}
            style={{ 
              textShadow: '0 0 8px rgba(255, 215, 0, 0.8)',
              animation: isWarning 
                ? 'pulse 1s ease-in-out infinite'
                : 'glow 1.5s ease-in-out infinite' 
            }}
          >
            {formattedTime}
          </motion.div>
        </div>

        <div className="flex flex-col items-center">
          <h2 className="text-sm uppercase text-gray-400 font-rubik">Current Pot</h2>
          <motion.div 
            key={potAmount.toFixed(1)}
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.3 }}
            className="text-4xl font-orbitron font-bold text-[#00C853]"
          >
            {potAmount.toFixed(1)} WLD
          </motion.div>
        </div>
      </div>
      
      <div 
        className="w-full h-1 mt-4 rounded-sm relative overflow-hidden bg-gradient-to-r from-[#FFD700] to-[#FF6B00]"
        style={{ 
          backgroundSize: '200% 100%',
          backgroundPosition: `${(1 - timeInSeconds / 240) * 100}% 0` 
        }}
      >
        <div 
          className="absolute top-0 left-0 w-full h-full"
          style={{
            width: `${(timeInSeconds / 240) * 100}%`,
            background: 'linear-gradient(90deg, #FFD700, #FF6B00)',
            transition: 'width 1s linear'
          }}
        ></div>
      </div>
    </div>
  );
}
