
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Settings() {
  return (
    <Sheet>
      <SheetTrigger className="absolute top-4 right-4 text-2xl cursor-pointer hover:opacity-80">
        ⚙️
      </SheetTrigger>
      <SheetContent className="bg-[#1a2e44] border-[#234863] text-white">
        <SheetHeader>
          <SheetTitle className="text-[#FFD700] font-orbitron">Ajustes</SheetTitle>
        </SheetHeader>
        
        <div className="mt-6 space-y-6">
          {/* Idioma */}
          <div className="space-y-2">
            <label className="text-sm flex items-center gap-2">
              🈳 Idioma
            </label>
            <Select defaultValue="es">
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Seleccionar idioma" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="es">Español 🇪🇸</SelectItem>
                <SelectItem value="en">Inglés 🇬🇧</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Sonido */}
          <div className="space-y-2">
            <label className="text-sm flex items-center gap-2">
              🔊 Sonido
              <Switch />
            </label>
          </div>

          {/* Notificaciones */}
          <div className="space-y-2">
            <label className="text-sm flex items-center gap-2">
              🔔 Notificaciones
              <Switch />
            </label>
          </div>

          {/* Reglas */}
          <div className="mt-8 space-y-2">
            <h3 className="font-medium text-[#FFD700]">📜 Reglas y condiciones</h3>
            <div className="text-sm text-gray-300 space-y-4 max-h-60 overflow-y-auto">
              <p>Objetivo del juego: Presiona el botón militar para convertirte en el último jugador antes de que la bomba explote. Si nadie más presiona en 4 minutos, ¡tú ganas el pozo!</p>
              
              <div>
                <p className="font-medium mb-1">Participación:</p>
                <ul className="list-disc pl-4 space-y-1">
                  <li>Cada botón cuesta 0.1 WLD.</li>
                  <li>El temporizador se reinicia a 4:00 minutos.</li>
                  <li>Su nombre aparece como el último jugador.</li>
                  <li>Se suma 0.1 WLD al pozo acumulado.</li>
                </ul>
              </div>

              <div>
                <p className="font-medium mb-1">Comisiones:</p>
                <ul className="list-disc pl-4 space-y-1">
                  <li>10% se queda el creador del juego.</li>
                  <li>5% se transfiere al pozo de la siguiente ronda.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
