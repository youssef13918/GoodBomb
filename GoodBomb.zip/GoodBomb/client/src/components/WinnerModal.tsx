import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface WinnerModalProps {
  winner: string | null;
  amount: number;
}

export default function WinnerModal({ winner, amount }: WinnerModalProps) {
  const [countdown, setCountdown] = useState(5);
  
  // Countdown timer for auto-restart
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        const newCount = prev - 1;
        return newCount < 0 ? 0 : newCount;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);

  return (
    <AnimatePresence>
      <motion.div 
        className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <motion.div 
          className="max-w-md w-full bg-[#0D1B2A] border-4 border-[#FFD700] rounded-xl p-8 m-4"
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", damping: 15 }}
        >
          <div className="text-center">
            <motion.h2 
              className="text-5xl font-bold font-orbitron text-[#FF8800] mb-4"
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 0.5, times: [0, 0.5, 1] }}
            >
              BOOM!
            </motion.h2>
            
            <div className="text-xl font-rubik mb-6">
              <span className="text-[#00C853] text-2xl font-bold">
                {winner || 'Nobody'}
              </span> won 
              <span className="text-[#00C853] text-2xl font-bold ml-2">
                {amount.toFixed(1)} WLD
              </span>
            </div>
            
            <p className="text-gray-300 mb-6">
              The bomb has exploded! A new round will start automatically.
            </p>
            
            <div className="text-[#FFD700] text-2xl font-orbitron">
              Restarting in <span>{countdown}</span>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
