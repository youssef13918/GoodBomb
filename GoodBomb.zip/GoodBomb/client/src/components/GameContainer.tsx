import { ReactNode } from 'react';

interface GameContainerProps {
  children: ReactNode;
}

import Settings from './Settings';

export default function GameContainer({ children }: GameContainerProps) {
  return (
    <div className="game-container max-w-md w-full px-4 py-8 flex flex-col items-center relative">
      <Settings />
      {/* Game Header */}
      <div className="w-full flex flex-col items-center mb-4">
        <h1 className="text-4xl font-bold font-orbitron text-[#FFD700] mb-2">GOODBOMB</h1>
        <p className="text-sm text-gray-300 font-rubik mb-4">Press the button or watch it explode!</p>
      </div>

      {/* Main content - CountdownTimer, PotAmount, BombGraphic, ActionButton, LastPlayerInfo */}
      {children}
    </div>
  );
}
