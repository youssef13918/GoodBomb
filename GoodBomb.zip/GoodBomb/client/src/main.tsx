import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Custom fonts
import "@fontsource/orbitron/400.css";
import "@fontsource/orbitron/700.css";
import "@fontsource/orbitron/900.css";
import "@fontsource/rubik/400.css";
import "@fontsource/rubik/500.css";
import "@fontsource/rubik/700.css";

createRoot(document.getElementById("root")!).render(<App />);
