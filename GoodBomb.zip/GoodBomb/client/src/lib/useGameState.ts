import { createContext, useContext } from 'react';
import { GameState } from '@shared/schema';

interface GameStateContextType {
  gameState: GameState | null;
  isConnected: boolean;
  isExploding: boolean;
  showWinnerModal: boolean;
  winnerInfo: {
    winner: string | null;
    amount: number;
  };
  pressButton: (walletAddress: string) => void;
}

const initialGameState: GameState = {
  timerSeconds: 240,
  potAmount: 0,
  lastPlayer: null,
  isExploded: false,
  isGameActive: true,
  playerCount: 0,
  recentPlayers: []
};

export const GameStateContext = createContext<GameStateContextType>({
  gameState: initialGameState,
  isConnected: false,
  isExploding: false,
  showWinnerModal: false,
  winnerInfo: {
    winner: null,
    amount: 0
  },
  pressButton: () => {}
});

export const useGameState = () => useContext(GameStateContext);
