import { useState, useEffect, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';

type WorldAppState = {
  isAvailable: boolean;
  isConnected: boolean;
  walletAddress: string | null;
  connecting: boolean;
  error: string | null;
};

export function useWorldApp() {
  const [state, setState] = useState<WorldAppState>({
    isAvailable: false,
    isConnected: false,
    walletAddress: null,
    connecting: false,
    error: null,
  });
  const { toast } = useToast();

  // Check if World App is available
  useEffect(() => {
    const checkAvailability = () => {
      const isAvailable = 
        typeof window !== 'undefined' && 
        'worldApp' in window && 
        typeof (window as any).worldApp === 'object';

      setState(prev => ({
        ...prev,
        isAvailable,
        error: isAvailable ? null : 'World App is not available in this browser'
      }));
    };

    checkAvailability();
    
    // Also check when the document is fully loaded (in case script loads late)
    window.addEventListener('load', checkAvailability);
    return () => window.removeEventListener('load', checkAvailability);
  }, []);

  // Connect to World App wallet
  const connect = useCallback(async () => {
    if (!state.isAvailable) {
      setState(prev => ({
        ...prev,
        error: 'World App is not available'
      }));
      return;
    }

    try {
      setState(prev => ({ ...prev, connecting: true, error: null }));
      
      const worldApp = (window as any).worldApp;
      
      // Request wallet connection
      const result = await worldApp.connect();
      
      if (result?.account) {
        setState(prev => ({
          ...prev,
          isConnected: true,
          walletAddress: result.account,
          connecting: false
        }));
      } else {
        throw new Error('Failed to connect to wallet');
      }
    } catch (error) {
      console.error('Connection error:', error);
      setState(prev => ({
        ...prev,
        connecting: false,
        error: error instanceof Error ? error.message : 'Unknown error connecting to wallet'
      }));
      
      toast({
        title: "Connection Failed",
        description: "Could not connect to World App wallet",
        variant: "destructive"
      });
    }
  }, [state.isAvailable, toast]);

  // Send a transaction
  const sendTransaction = useCallback(async (amount: number) => {
    if (!state.isConnected || !state.walletAddress) {
      setState(prev => ({
        ...prev,
        error: 'Wallet not connected'
      }));
      return null;
    }

    try {
      const worldApp = (window as any).worldApp;
      
      // Format amount with proper decimal places (WLD uses 18 decimals)
      const amountInWei = (amount * 10**18).toString();
      
      // Send transaction
      const result = await worldApp.sendTransaction({
        to: "0x0000000000000000000000000000000000000001", // This should be replaced with the actual game contract address
        value: amountInWei
      });
      
      return result;
    } catch (error) {
      console.error('Transaction error:', error);
      setState(prev => ({
        ...prev,
        error: error instanceof Error ? error.message : 'Unknown error sending transaction'
      }));
      
      toast({
        title: "Transaction Failed",
        description: "Could not complete the payment",
        variant: "destructive"
      });
      
      return null;
    }
  }, [state.isConnected, state.walletAddress, toast]);

  return {
    ...state,
    connect,
    sendTransaction
  };
}
