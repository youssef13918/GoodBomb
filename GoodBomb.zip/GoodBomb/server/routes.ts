import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { log } from "./vite";
import { WSMessage, GameState } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);
  
  // Create WebSocket server
  const wss = new WebSocketServer({ 
    server: httpServer, 
    path: '/ws'
  });
  
  // Store connected clients
  const clients = new Set<WebSocket>();
  
  // Game state timer
  let gameInterval: NodeJS.Timeout | null = null;
  
  // Function to broadcast game state to all connected clients
  const broadcastGameState = async () => {
    const gameState = await storage.getGameState();
    
    const message: WSMessage = {
      type: 'gameState',
      payload: gameState
    };
    
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(message));
      }
    });
    
    return gameState;
  };
  
  // Function to handle game timer
  const startGameTimer = async () => {
    // Clear any existing interval
    if (gameInterval) {
      clearInterval(gameInterval);
    }
    
    gameInterval = setInterval(async () => {
      const gameState = await storage.getGameState();
      
      if (gameState.isGameActive && !gameState.isExploded) {
        // Decrement timer
        const currentTime = Math.max(0, gameState.timerSeconds - 1);
        
        // Update the game in storage
        const activeGame = await storage.getActiveGame();
        if (activeGame) {
          await storage.updateGame(activeGame.id, {
            timerSeconds: currentTime
          });
        }
        
        // If timer reaches zero, handle explosion
        if (currentTime === 0) {
          await handleExplosion();
        } else {
          // Otherwise broadcast the updated state
          await broadcastGameState();
        }
      }
    }, 1000);
  };
  
  // Function to handle bomb explosion
  const handleExplosion = async () => {
    const activeGame = await storage.getActiveGame();
    if (!activeGame) return;
    
    // Update game state to exploded
    await storage.updateGame(activeGame.id, {
      isExploded: true,
      isGameActive: false
    });
    
    // Get updated game state after explosion
    const gameState = await storage.getGameState();
    
    // Send explosion message to all clients
    const explosionMessage: WSMessage = {
      type: 'explosion',
      payload: {
        winner: gameState.lastPlayer,
        amount: gameState.potAmount
      }
    };
    
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(explosionMessage));
      }
    });
    
    // Schedule game reset after 5 seconds
    setTimeout(async () => {
      const newGameState = await storage.resetGame();
      
      // Send game reset message
      const resetMessage: WSMessage = {
        type: 'gameReset',
        payload: newGameState
      };
      
      clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify(resetMessage));
        }
      });
    }, 5000);
  };
  
  // WebSocket connection handler
  wss.on('connection', (ws) => {
    log('WebSocket client connected');
    
    // Add client to the set
    clients.add(ws);
    
    // Increment player count
    const playerCount = (storage as any).incrementConnectedPlayers();
    
    // Send current game state to the new connection
    storage.getGameState().then(gameState => {
      // Send connection confirmation
      const connectionMessage: WSMessage = {
        type: 'connection',
        payload: { connected: true }
      };
      ws.send(JSON.stringify(connectionMessage));
      
      // Send game state
      const stateMessage: WSMessage = {
        type: 'gameState',
        payload: gameState
      };
      ws.send(JSON.stringify(stateMessage));
      
      // Broadcast updated player count
      const countMessage: WSMessage = {
        type: 'playerCount',
        payload: { count: playerCount }
      };
      
      clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify(countMessage));
        }
      });
    });
    
    // Handle messages from clients
    ws.on('message', async (data) => {
      try {
        const message: WSMessage = JSON.parse(data.toString());
        
        // Handle button press
        if (message.type === 'buttonPress' && message.payload) {
          const { walletAddress } = message.payload;
          
          // Process button press in storage
          await storage.pressButton(walletAddress, 0.1);
          
          // Broadcast updated game state
          await broadcastGameState();
        }
      } catch (err) {
        log(`Error handling WebSocket message: ${err}`, 'websocket');
      }
    });
    
    // Handle client disconnect
    ws.on('close', () => {
      log('WebSocket client disconnected');
      
      // Remove client from the set
      clients.delete(ws);
      
      // Decrement player count
      const playerCount = (storage as any).decrementConnectedPlayers();
      
      // Broadcast updated player count
      const countMessage: WSMessage = {
        type: 'playerCount',
        payload: { count: playerCount }
      };
      
      clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify(countMessage));
        }
      });
    });
  });
  
  // Start game timer when server starts
  startGameTimer();
  
  // API route to get current game state
  app.get('/api/game/state', async (req, res) => {
    try {
      const gameState = await storage.getGameState();
      res.json(gameState);
    } catch (err) {
      res.status(500).json({ error: 'Failed to get game state' });
    }
  });
  
  // API route to press the button (alternative to WebSocket)
  app.post('/api/game/press', async (req, res) => {
    try {
      const { walletAddress } = req.body;
      
      if (!walletAddress) {
        return res.status(400).json({ error: 'Wallet address is required' });
      }
      
      const gameState = await storage.pressButton(walletAddress, 0.1);
      
      // Broadcast updated state to all clients
      await broadcastGameState();
      
      res.json(gameState);
    } catch (err) {
      res.status(500).json({ error: 'Failed to press button' });
    }
  });

  return httpServer;
}
