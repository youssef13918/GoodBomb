import { 
  games, type Game, type InsertGame,
  players, type Player, type InsertPlayer,
  GameState
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  getActiveGame(): Promise<Game | undefined>;
  createGame(game: InsertGame): Promise<Game>;
  updateGame(id: number, game: Partial<Game>): Promise<Game>;
  addPlayer(player: InsertPlayer): Promise<Player>;
  getPlayersByGame(gameId: number): Promise<Player[]>;
  getLastPlayer(gameId: number): Promise<Player | undefined>;
  getGameState(): Promise<GameState>;
  pressButton(walletAddress: string, amount: number): Promise<GameState>;
  resetGame(): Promise<GameState>;
}

// In-memory implementation of storage
export class MemStorage implements IStorage {
  private games: Map<number, Game>;
  private players: Map<number, Player>;
  private currentGameId: number;
  private currentPlayerId: number;
  private connectedPlayers: number;
  private recentPlayersList: string[]; // Lista de jugadores recientes

  constructor() {
    this.games = new Map();
    this.players = new Map();
    this.currentGameId = 1;
    this.currentPlayerId = 1;
    this.connectedPlayers = 0;
    this.recentPlayersList = []; // Inicializamos la lista vacía
    
    // Initialize a game
    this.initializeGame();
  }

  private initializeGame(): void {
    const initialGame: Game = {
      id: this.currentGameId,
      timerSeconds: 240,
      potAmount: "0", // Using string for numeric type
      lastPlayerWallet: null,
      isExploded: false,
      isGameActive: true,
      lastUpdated: new Date()
    };
    
    this.games.set(this.currentGameId, initialGame);
  }

  async getActiveGame(): Promise<Game | undefined> {
    // Find the active game (there should be only one)
    for (const game of this.games.values()) {
      if (game.isGameActive) {
        return game;
      }
    }
    return undefined;
  }

  async createGame(insertGame: InsertGame): Promise<Game> {
    const id = this.currentGameId++;
    const game: Game = {
      ...insertGame,
      id,
      potAmount: typeof insertGame.potAmount === 'number' ? insertGame.potAmount.toString() : insertGame.potAmount || "0",
      lastUpdated: new Date()
    };
    this.games.set(id, game);
    return game;
  }

  async updateGame(id: number, partialGame: Partial<Game>): Promise<Game> {
    const existingGame = this.games.get(id);
    if (!existingGame) {
      throw new Error(`Game with id ${id} not found`);
    }
    
    const updatedGame: Game = {
      ...existingGame,
      ...partialGame,
      potAmount: typeof partialGame.potAmount === 'number' 
        ? partialGame.potAmount.toString() 
        : partialGame.potAmount || existingGame.potAmount,
      lastUpdated: new Date()
    };
    
    this.games.set(id, updatedGame);
    return updatedGame;
  }

  async addPlayer(insertPlayer: InsertPlayer): Promise<Player> {
    const id = this.currentPlayerId++;
    const player: Player = {
      ...insertPlayer,
      id,
      buttonPressTime: new Date()
    };
    this.players.set(id, player);
    return player;
  }

  async getPlayersByGame(gameId: number): Promise<Player[]> {
    return Array.from(this.players.values())
      .filter(player => player.gameId === gameId);
  }

  async getLastPlayer(gameId: number): Promise<Player | undefined> {
    const players = await this.getPlayersByGame(gameId);
    if (players.length === 0) return undefined;
    
    // Sort by buttonPressTime descending to get the most recent
    return players.sort((a, b) => 
      b.buttonPressTime.getTime() - a.buttonPressTime.getTime()
    )[0];
  }

  // Helper to convert string numeric to number for API
  private numericToNumber(numeric: string): number {
    return parseFloat(numeric);
  }

  // Get current game state for WebSocket updates
  async getGameState(): Promise<GameState> {
    const game = await this.getActiveGame();
    if (!game) {
      // Create a new game if none exists
      const newGame = await this.createGame({
        timerSeconds: 240,
        potAmount: "0",
        lastPlayerWallet: null,
        isExploded: false,
        isGameActive: true
      });
      
      return {
        timerSeconds: newGame.timerSeconds,
        potAmount: this.numericToNumber(newGame.potAmount),
        lastPlayer: newGame.lastPlayerWallet,
        isExploded: newGame.isExploded,
        isGameActive: newGame.isGameActive,
        playerCount: this.connectedPlayers,
        recentPlayers: this.recentPlayersList
      };
    }

    return {
      timerSeconds: game.timerSeconds,
      potAmount: this.numericToNumber(game.potAmount),
      lastPlayer: game.lastPlayerWallet,
      isExploded: game.isExploded,
      isGameActive: game.isGameActive,
      playerCount: this.connectedPlayers,
      recentPlayers: this.recentPlayersList
    };
  }
  
  // Handle button press from a player
  async pressButton(walletAddress: string, amount: number): Promise<GameState> {
    const game = await this.getActiveGame();
    if (!game || !game.isGameActive || game.isExploded) {
      throw new Error("No active game available");
    }
    
    // Add player to the current game
    await this.addPlayer({
      walletAddress,
      gameId: game.id
    });
    
    // Agregar jugador a la lista de jugadores recientes
    // Si el jugador ya está en la lista, lo movemos al principio
    this.recentPlayersList = this.recentPlayersList.filter(player => player !== walletAddress);
    // Agregamos el jugador al principio de la lista
    this.recentPlayersList.unshift(walletAddress);
    // Mantenemos solo los últimos 10 jugadores
    if (this.recentPlayersList.length > 10) {
      this.recentPlayersList = this.recentPlayersList.slice(0, 10);
    }
    
    // Update the game state
    const currentPot = this.numericToNumber(game.potAmount);
    const updatedGame = await this.updateGame(game.id, {
      timerSeconds: 240, // Reset timer to 4 minutes
      potAmount: (currentPot + amount).toString(),
      lastPlayerWallet: walletAddress
    });
    
    return {
      timerSeconds: updatedGame.timerSeconds,
      potAmount: this.numericToNumber(updatedGame.potAmount),
      lastPlayer: updatedGame.lastPlayerWallet,
      isExploded: updatedGame.isExploded,
      isGameActive: updatedGame.isGameActive,
      playerCount: this.connectedPlayers,
      recentPlayers: this.recentPlayersList
    };
  }
  
  // Reset the game after explosion
  async resetGame(): Promise<GameState> {
    // First, set the current game as inactive
    const currentGame = await this.getActiveGame();
    if (currentGame) {
      await this.updateGame(currentGame.id, {
        isGameActive: false
      });
    }
    
    // Create a new game
    const newGame = await this.createGame({
      timerSeconds: 240,
      potAmount: "0",
      lastPlayerWallet: null,
      isExploded: false,
      isGameActive: true
    });
    
    // Conservamos la lista de jugadores recientes para el nuevo juego
    return {
      timerSeconds: newGame.timerSeconds,
      potAmount: this.numericToNumber(newGame.potAmount),
      lastPlayer: newGame.lastPlayerWallet,
      isExploded: newGame.isExploded,
      isGameActive: newGame.isGameActive,
      playerCount: this.connectedPlayers,
      recentPlayers: this.recentPlayersList
    };
  }
  
  // Track connected players
  incrementConnectedPlayers(): number {
    return ++this.connectedPlayers;
  }
  
  decrementConnectedPlayers(): number {
    return --this.connectedPlayers;
  }
}

// Create and export a single instance to be used throughout the application
export const storage = new MemStorage();
