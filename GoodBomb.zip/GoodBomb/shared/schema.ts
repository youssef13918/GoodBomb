import { pgTable, text, serial, integer, boolean, timestamp, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Game schema to store the current game state
export const games = pgTable("games", {
  id: serial("id").primaryKey(),
  timerSeconds: integer("timer_seconds").notNull().default(240),
  potAmount: numeric("pot_amount", { precision: 10, scale: 2 }).notNull().default("0"),
  lastPlayerWallet: text("last_player_wallet"),
  isExploded: boolean("is_exploded").notNull().default(false),
  isGameActive: boolean("is_game_active").notNull().default(true),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

// Players schema to store player actions
export const players = pgTable("players", {
  id: serial("id").primaryKey(),
  walletAddress: text("wallet_address").notNull(),
  gameId: integer("game_id").notNull(),
  buttonPressTime: timestamp("button_press_time").notNull().defaultNow(),
});

// Game insert schema
export const insertGameSchema = createInsertSchema(games).omit({
  id: true,
  lastUpdated: true
});

// Player insert schema
export const insertPlayerSchema = createInsertSchema(players).omit({
  id: true,
  buttonPressTime: true
});

// Create types for use in the application
export type Game = typeof games.$inferSelect;
export type InsertGame = z.infer<typeof insertGameSchema>;
export type Player = typeof players.$inferSelect;
export type InsertPlayer = z.infer<typeof insertPlayerSchema>;

// Define WebSocket message types
export type WSMessageType = 
  | 'gameState'      // Server sends updated game state
  | 'buttonPress'    // Client presses button
  | 'explosion'      // Server notifies of explosion
  | 'gameReset'      // Server notifies of game reset
  | 'connection'     // Client connects to game
  | 'playerCount';   // Server sends current player count

// Define WebSocket message structure
export interface WSMessage {
  type: WSMessageType;
  payload?: any;
}

// Define game state structure for WebSocket communications
export interface GameState {
  timerSeconds: number;
  potAmount: number;
  lastPlayer: string | null;
  isExploded: boolean;
  isGameActive: boolean;
  playerCount: number;
  recentPlayers: string[]; // Lista de los jugadores recientes
}
