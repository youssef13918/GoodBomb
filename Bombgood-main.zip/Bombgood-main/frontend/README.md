# minikit-js-template

Template repository for building a mini app in vanilla JS

## MiniKit delivery

Here we opted for a CDN delivery of MiniKit. You can also of course use the NPM package - see the [React template](https://github.com/worldcoin/minikit-react-template) for reference.