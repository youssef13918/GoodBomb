import { useEffect } from 'react';
import { useGameState } from '@/lib/useGameState';
import GameContainer from '@/components/GameContainer';
import BombGraphic from '@/components/BombGraphic';
import CountdownTimer from '@/components/CountdownTimer';
import PotAmount from '@/components/PotAmount';
import ActionButton from '@/components/ActionButton';
import LastPlayerInfo from '@/components/LastPlayerInfo';
import WinnerModal from '@/components/WinnerModal';
import GameInstructions from '@/components/GameInstructions';
import RecentPlayersList from '@/components/RecentPlayersList';
import { Card } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useWorldApp } from '@/lib/useWorldApp';

export default function GamePage() {
  const { 
    gameState, 
    isConnected, 
    isExploding, 
    showWinnerModal, 
    winnerInfo 
  } = useGameState();
  
  const { 
    isAvailable: isWorldAppAvailable,
    isConnected: isWalletConnected,
    walletAddress,
    connect
  } = useWorldApp();
  
  const { toast } = useToast();
  
  // Connect to wallet when the page loads if World App is available
  useEffect(() => {
    if (isWorldAppAvailable && !isWalletConnected) {
      connect();
    }
  }, [isWorldAppAvailable, isWalletConnected, connect]);
  
  // Show connection status
  useEffect(() => {
    if (!isConnected) {
      toast({
        title: "Connecting to Game Server",
        description: "Please wait while we connect to the game server..."
      });
    }
  }, [isConnected, toast]);

  if (!gameState) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0D1B2A]">
        <Card className="p-6 text-center">
          <h1 className="text-2xl font-orbitron text-[#FFD700] mb-4">GOODBOMB</h1>
          <p className="text-white">Connecting to game server...</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0D1B2A] text-white flex flex-col items-center justify-center py-8">
      <GameContainer>
        <CountdownTimer 
          timeInSeconds={gameState.timerSeconds} 
          isWarning={gameState.timerSeconds <= 30 && !gameState.isExploded}
        />
        
        <LastPlayerInfo player={gameState.lastPlayer} />
        
        <PotAmount amount={gameState.potAmount} />
        
        <BombGraphic 
          timeInSeconds={gameState.timerSeconds} 
          isShaking={gameState.timerSeconds <= 30 && !gameState.isExploded}
          isExploding={isExploding}
        />
        
        <ActionButton 
          disabled={!isWalletConnected || !gameState.isGameActive || gameState.isExploded}
          walletAddress={walletAddress}
        />
        
        <LastPlayerInfo player={gameState.lastPlayer} />
        
        <RecentPlayersList />
      </GameContainer>
      
      <GameInstructions />
      
      {showWinnerModal && (
        <WinnerModal 
          winner={winnerInfo.winner} 
          amount={winnerInfo.amount} 
        />
      )}
    </div>
  );
}
